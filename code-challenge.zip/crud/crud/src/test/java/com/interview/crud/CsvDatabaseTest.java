package com.interview.crud;

import com.interview.crud.services.CsvDatabase;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class CsvDatabaseTest {

	private CsvDatabase csvDatabase;

	@BeforeEach
	public void setUp() {
		String csvFilePath = "test-data.csv";

		// Clear the content of the CSV file
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(csvFilePath))) {
			writer.write(""); // Overwrite with an empty string
		} catch (IOException e) {
			e.printStackTrace();
		}

		csvDatabase = new CsvDatabase();
		csvDatabase.CSV_FILE = csvFilePath;
	}

	@Test
	public void testInsertAndSelect() {
		String testRow = "Test data";
		Long newId = csvDatabase.insert(testRow);
		List<String> selectedRows = csvDatabase.select(newId);
		assertTrue(selectedRows.size() == 1);
		assertEquals(newId + "," + testRow, selectedRows.get(0));
	}

	@Test
	public void testUpdate() {
		String initialRow = "Initial data";
		Long newId = csvDatabase.insert(initialRow);

		String updatedRow = "Updated data";
		assertTrue(csvDatabase.update(newId, updatedRow));

		List<String> selectedRows = csvDatabase.select(newId);
		assertTrue(selectedRows.size() == 1);
		assertEquals(newId + "," + updatedRow, selectedRows.get(0));
		setUp();
	}

	@Test
	public void testDelete() {
		String testRow = "Test data";
		Long newId = csvDatabase.insert(testRow);

		assertTrue(csvDatabase.delete(newId));

		List<String> selectedRows = csvDatabase.select(newId);
		assertTrue(selectedRows.isEmpty());
	}
}
