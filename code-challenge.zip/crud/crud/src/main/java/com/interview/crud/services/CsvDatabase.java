package com.interview.crud.services;

import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Service

public class CsvDatabase implements Database {
    public static String CSV_FILE = "data.csv";

    @Override
    public List<String> select(Long id) {
        List<String> rows = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (id == -1L || line.startsWith(id + ",")) {
                    rows.add(line);
                }
            }
        } catch (IOException e) {
            handleIOException(e);
        }
        return rows;
    }

    @Override
    public Long insert(String row) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE, true))) {
            Long newId = generateUniqueId();
            writer.write(newId + "," + row);
            writer.newLine();
            return newId;
        } catch (IOException e) {
            handleIOException(e);
            return -1L;
        }
    }

    @Override
    public boolean update(Long id, String newRow) {
        List<String> updatedRows = new ArrayList<>();
        boolean updated = false;
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(id + ",")) {
                    updatedRows.add(id + "," + newRow);
                    updated = true;
                } else {
                    updatedRows.add(line);
                }
            }
        } catch (IOException e) {
            handleIOException(e);
        }

        if (updated) {
            writeRowsToFile(updatedRows);
        }
        return updated;
    }

    @Override
    public boolean delete(Long id) {
        List<String> remainingRows = new ArrayList<>();
        boolean deleted = false;
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.startsWith(id + ",")) {
                    remainingRows.add(line);
                } else {
                    deleted = true;
                }
            }
        } catch (IOException e) {
            handleIOException(e);
        }

        if (deleted) {
            writeRowsToFile(remainingRows);
        }
        return deleted;
    }

    private synchronized Long generateUniqueId() {
        return idCounter++;
    }

    private void writeRowsToFile(List<String> rows) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE))) {
            for (String row : rows) {
                writer.write(row);
                writer.newLine();
            }
        } catch (IOException e) {
            handleIOException(e);
        }
    }

    private void handleIOException(IOException e) {
        e.printStackTrace();
    }

    private Long idCounter = 1L;
}
