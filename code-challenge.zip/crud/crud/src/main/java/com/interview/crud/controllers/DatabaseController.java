package com.interview.crud.controllers;

import com.interview.crud.services.CsvDatabase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class DatabaseController {
    private final CsvDatabase csvDatabase;

    @Autowired
    public DatabaseController(CsvDatabase csvDatabase) {
        this.csvDatabase = csvDatabase;
    }

    @GetMapping("/select/{id}")
    public List<String> select(@PathVariable Long id) {
        return csvDatabase.select(id);
    }

    @PostMapping("/insert")
    public Long insert(@RequestBody String row) {
        return csvDatabase.insert(row);
    }

    @PutMapping("/update/{id}")
    public boolean update(@PathVariable Long id, @RequestBody String newRow) {
        return csvDatabase.update(id, newRow);
    }

    @DeleteMapping("/delete/{id}")
    public boolean delete(@PathVariable Long id) {
        return csvDatabase.delete(id);
    }
}
